#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/ioctl.h>
#include<linux/fs.h>
#include<linux/kernel.h>
#include<malloc.h>
#include<stdbool.h>

#define BUFFER_SIZE 1024

int main(){
	char *buffer = (char*)malloc(BUFFER_SIZE*sizeof(char));
	int bufferLength = 0;
	int length = 0;
	int offSet = 0;
	int whence = 0;
	bool test = true;
	char userInput;
	int file = open("/dev/pa2_char_device", O_RDWR);
	if(file >= 0){
		printf("File opened \n");
		//buffer = (char*)malloc(BUFFER_SIZE*sizeof(char));
		while(test){
			printf("Displaying Menu:\n");
			printf("Press 'r' to read from device\n");
			printf("Press 'w' to wrtie to device\n");
			printf("Press 's' to seek from device\n");
			printf("Press 'e' to exit\n");
			printf("Please enter your input: ");
			scanf("%c",&userInput);
			switch(userInput){
				case 'w':
					printf("Enter what you want to write to the device: \n");
					scanf(" %[^\n]",buffer);
					int bufferLength = strlen(buffer);
					if(bufferLength > BUFFER_SIZE || bufferLength < 0){
						printf("ERROR! Length is out of the boundaries\n");
					}	
		
					write(file,buffer,bufferLength);
					while(getchar() != '\n');
					free(buffer);
					break;
				/*
				---------------------------------------------
				*/
				case 's':
					printf("Seek Menu:\n");
					printf("Press 0 to seek set\n");
					printf("Press 1 to seek current\n");
					printf("Press 2 to send\n");
					printf("ENTER WHENCE VALUE: \n");
					scanf("%d", &whence);
					printf("ENTER OFFSET VALUE: \n");
					scanf("%d", &offSet);
		
					lseek(file,offSet,whence);
				
					break;
		
				/*
				---------------------------------------
				*/
				case 'r':
					printf("How many bytes do you want to read?: ");
					scanf("%d", &length);
					read(file,buffer,length);
					if(length > BUFFER_SIZE || length < 0){
						printf("ERROR! Length is out of the boudaries");
					}
					printf("Data that's read from device: %s\n", buffer);
					while(getchar() != '\n');
					break;
				case 'e':
					test = false;
					break;
				default: 
					printf("Invalid input! Please select from one of the options.\n");
			}
		}
		
		
	}
	else{
		printf("File failed to open \n");
	}
	close(file);
	return 0;
}

