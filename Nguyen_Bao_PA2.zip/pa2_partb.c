#include<linux/init.h>
#include<linux/module.h>
#include<linux/fs.h>
#include<linux/slab.h>
#include<linux/uaccess.h>

#define BUFFER_SIZE 1024
int openCount = 0;
int closeCount = 0;
char *deviceBuffer;


int my_open(struct inode *pinode, struct file *myfile){
	printk(KERN_ALERT "The device has opened \n");
	openCount++;
	printk(KERN_ALERT "The device has opened %d times \n", openCount);
	return 0;
}

int my_close(struct inode *pinode, struct file *myfile){
	printk(KERN_ALERT "The device has closed \n");
	closeCount++;
	printk(KERN_ALERT "The device has closed %d times \n", closeCount);
	return 0;
}

ssize_t my_read(struct file *myfile, char __user *buffer, size_t length, loff_t *offset ){
	printk(KERN_ALERT "INSIDE READ FUNCTION");
	int bytesLeft;
	int bytesAlreadyRead;
	if(length > BUFFER_SIZE){
		printk(KERN_ALERT "ERROR! Length is over buffer limits! \n");
		length = BUFFER_SIZE;	
	}
	if(length < 0){
		printk(KERN_ALERT "ERROR! Length is less than 0! \n");	 
		length = BUFFER_SIZE;
	}
	if(BUFFER_SIZE - *offset > length){
		bytesLeft = length;	
	}
	else{
		bytesLeft = BUFFER_SIZE - length;
	}
	
	bytesAlreadyRead = bytesLeft - copy_to_user(buffer, deviceBuffer+*offset,bytesLeft);

	*offset += bytesAlreadyRead;
	
	printk(KERN_ALERT "Total bytes = %d\n", bytesAlreadyRead);
	printk(KERN_ALERT "Offset = %lld \n",*offset);
	return bytesAlreadyRead;

}

ssize_t my_write(struct file *myfile, const char __user *buffer, size_t length, loff_t *offset){
	printk(KERN_ALERT "INSIDE WRITE FUNCTION");
	if(length > BUFFER_SIZE || length < 0){
		printk(KERN_ALERT "ERROR! Length is over buffer limits\n");
		length = BUFFER_SIZE;	
	}
	copy_from_user(deviceBuffer + *offset,buffer,length);
	*offset += length;
	printk(KERN_ALERT "Offset = %lld \n",*offset);
	return length;
}

loff_t my_seek (struct file *myfile, loff_t offset, int whence){
	printk(KERN_ALERT "INSIDE SEEK FUCNTION\n");
	
	int pos = 0;
	if(pos < 0 || pos > BUFFER_SIZE){
		printk(KERN_ALERT "ERROR! Out of Bounds!\n");	
	}
	if(whence == 0){
		pos = offset;	
	}
	else if(whence == 1){
		pos = myfile->f_pos + offset;
	}
	else if(whence == 2){
		pos = BUFFER_SIZE - offset;	
	}
	else{
		printk(KERN_ALERT"ERROR! Invalid input");	
	}
	myfile->f_pos = pos;
	printk(KERN_ALERT "The current postion is: %d \n",pos);
	return pos;
}



struct file_operations my_file_operations = {
    .owner   = THIS_MODULE,
    .open   = my_open,       // int my_open  (struct inode *, struct file *);
    .release = my_close,      // int my_close (struct inode *, struct file *);
    .read    = my_read,       // ssize_t my_read  (struct file *, char __user *, size_t, loff_t *);
    .write   = my_write,      // ssize_t my_write (struct file *, const char __user *, size_t, loff_t *);
    .llseek  = my_seek        // loff_t  my_seek  (struct file *, loff_t, int);
};

int pa2_partb_init(void){
	printk(KERN_ALERT "inside %s function\n",__FUNCTION__);
	register_chrdev(251, "pa2_char_device", &my_file_operations);
	
	deviceBuffer = kmalloc(BUFFER_SIZE, GFP_KERNEL);
	return 0;
}

void pa2_partb_exit(void){
	printk(KERN_ALERT "inside %s function\n", __FUNCTION__);
	kfree(deviceBuffer);
	unregister_chrdev(251, "pa2_char_device");
}

module_init(pa2_partb_init);
module_exit(pa2_partb_exit);
